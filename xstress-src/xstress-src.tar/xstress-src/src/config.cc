/*
xstress - amItz SMTP Stress Tester

(c) Amit Singh, amits@intoto.com, amitcz@yahoo.com
xk0der.wordpress.com

This software and related files are licensed under GNU GPL version 2
Please visit the following webpage for more details
http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

#include <fstream>
#include <stdlib.h>
#include <time.h>
#include "common.h"
#include "sendmail.h"
#include "config.h"

using namespace std;

char * ConfigVarsStr[]=
{
  " ",
  "SERVER",
  "PORT",
  "THREADS",
  "MAILS_PER_THREAD",
  "LOG_FILE",
  "TIMEOUT",
  " "
};

char *SectionsStr[]=
{
  " ",
  "[CONFIG]",
  "[TO]",
  "[FROM]",
  "[SUBJECT]",
  "[BODY]",
  "[ATTACHMENT]",
  " "
};

int Config::okay()
{
  return iOkay;
}

string Config::getTo()
{
  unsigned int size = toList.size(), ii;
  srand(time(0));
  ii = (rand()%size);
  if(size==0) return string("");
  return toList[ii]; 
}

string Config::getFrom()
{
  unsigned int size = fromList.size(), ii;
  srand(time(0));
  ii = (rand()%size);
  if(size==0) return string("");
  return fromList[ii]; 
}

string Config::getSubject()
{
  unsigned int size = subjectList.size(), ii;
  srand(time(0));
  ii = (rand()%size);
  if(size==0) return string("");
  return subjectList[ii]; 
}

string Config::getBody()
{
  unsigned int size = bodyList.size(), ii;
  srand(time(0));
  ii = (rand()%size);
  if(size==0) return string("");
  return bodyList[ii]; 
}

string Config::getAttachment()
{
  unsigned int size = attachList.size(), ii;
  srand(time(0));
  if(size==0) return string("");
  ii = (rand()%size);
  return attachList[ii]; 
}


Config::Config(string sConfigFile)
{
  char cBuffer[1024];
  int ii;
  string sLine;
  iOkay = 1;
  ifstream filp(sConfigFile.c_str());
  unsigned int currSection = 0;
  unsigned int configVar = 0;
  unsigned int configVarsFound = 0;
  string LValue;
  string RValue;

  //
  sServerIP = "";
  uiServerPort = 0;
  uiThreads = 0;
  uiMailsPerThread = 0;

  if(!filp.fail())
  {
    while(!filp.eof())
    {
      filp.getline(cBuffer,1023);
      sLine = cBuffer;

      // Comments
      if(sLine[0] == '#') continue;
      if(sLine.empty()) continue;

      // Check if it's a section
      if(sLine[0] =='[')
      {
        for(ii=1;ii<S_MAX;ii++)
        {
          if(sLine == SectionsStr[ii])
          {
            currSection = ii;
            break;
          }
        }
        continue;
      }

      switch(currSection)
      {
        case S_CONFIG:
          ii = sLine.find("=");
          LValue = sLine.substr(0,ii);
          RValue = sLine.substr(ii+1,sLine.length());

          configVar = C_NO_VAR;
          for(ii=1;ii<C_MAX;ii++)
          {
            if(LValue == ConfigVarsStr[ii])
            {
              configVar = ii;
              break;
            }
          }

          switch(configVar)
          {
            case C_SERVER:
              sServerIP = RValue;
              break;
            case C_PORT:
              uiServerPort = atoi(RValue.c_str());
              break;
            case C_THREADS:
              uiThreads = atoi(RValue.c_str());
              break;
            case C_MAILS_PER_THREAD:
              uiMailsPerThread = atoi(RValue.c_str());
              break;
            case C_TIMEOUT:
              uiTimeout = atoi(RValue.c_str());
              break;
            case C_LOG_FILE:
              sLogFile = RValue;
              break;
          }

          break;
        case S_TO:
            //cout << "Add to TO list " << sLine << endl;
            toList.push_back(sLine);
          break;
        case S_FROM:
            fromList.push_back(sLine);
          break;
        case S_SUBJECT:
            subjectList.push_back(sLine);
          break;
        case S_BODY:
            bodyList.push_back(sLine);
          break;
        case S_ATTACH:
            attachList.push_back(sLine);
          break;
      }

    }

    if(sServerIP.empty() || uiServerPort == 0 || uiThreads == 0)
    {
      iOkay = 0;
    }

  }
  else
  {
    iOkay = false;
  }

}
